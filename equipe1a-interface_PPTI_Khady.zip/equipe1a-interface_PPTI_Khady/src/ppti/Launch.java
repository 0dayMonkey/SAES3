package ppti;

import ppti.app.Main;

public class Launch {
    public static void main(String[] args) {
        Main.main(args);
    }
}