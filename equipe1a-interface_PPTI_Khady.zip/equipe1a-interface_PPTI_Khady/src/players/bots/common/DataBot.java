package players.bots.common;

public class DataBot {

	static public String message = "players.bots.common.DataBot";

}