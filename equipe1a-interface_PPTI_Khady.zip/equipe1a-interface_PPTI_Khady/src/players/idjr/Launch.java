package players.idjr;

import players.idjr.app.*;

public class Launch {
    public static void main(String[] args) {
        Main.main(args);
    }
}