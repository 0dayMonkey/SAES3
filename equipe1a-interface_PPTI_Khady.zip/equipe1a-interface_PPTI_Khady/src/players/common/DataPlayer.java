package players.common;

public class DataPlayer {

	static public String message = "players.common.DataPlayer";

}