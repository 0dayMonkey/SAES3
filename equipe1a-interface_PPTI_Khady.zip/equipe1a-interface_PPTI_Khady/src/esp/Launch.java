package esp;

import common.Data;

public class Launch {

	public static void main(String[] args) {
		System.out.println("Je suis l'esp, j'utilise aussi "+ Data.message);
	}

}
